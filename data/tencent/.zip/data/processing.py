#!/usr/bin/env python
# coding=utf-8


# processing dataset using pandas

import pandas as pd
import numpy as np
data_file = 'output_mz'
data = pd.read_csv(data_file,header = None,sep = '\t',names = ['query','app','label'])
print('data_positive_label"{}'.format(data['label'].mean()))
print('all_sample_length:{}'.format(len(data)))
print('total number of query: {}'.format(len(data['query'].unique())))
print(data[data['label']==1])

msk = np.random.rand(len(data)) < 0.8

train = data[msk]

test = data[~msk]
print(len(train))
print(len(test))

train.to_csv('train',header = None,index = None,sep = '\t')
test.to_csv('test',header = None,index = None,sep ='\t')
